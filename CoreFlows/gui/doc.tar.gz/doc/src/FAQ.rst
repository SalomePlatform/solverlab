
.. include:: ../rst_prolog.rst

.. _iraFaq:

************************************
Add an Item in this FAQ
************************************

Edit *solverlabGUI/doc/src/FAQ.rst* and read documentation :ref:`iraDocumentation_compilation`.


************************************
FAQ
************************************


Why there is NOT all options of Solverlab code in SolverlabObjects tree ?
..........................................................................

Default user mode is set to **simple**, for beginners use.

Select action *change user mode* in contextual menu of *Solverlab* node of tree
(which is first line/node of tree).

.. image:: images/iraUserMode1.png
   :align: center

Then Apply as **advanced**.

.. image:: images/iraUserMode2.png
   :align: center

User can edit/modify value *General.usermode* parameter in the
:ref:`iraConfiguration`, to get a permanent setting.


Next question ?
...........................

Here there is your next answer etc.



