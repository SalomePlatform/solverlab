
.. include:: ../rst_prolog.rst


.. _modelUsage:

Model
---------

This section will explicit all options of the implemented model in the GUI


Diffusion Equation
--------------------

You can see the documentation here (TODO put link to solverlab git hub doc)

For this model 3 values are mandatories and 3 optionals
(TODO pictures of the model)

Some value can be a scalar or use a field already in your .med file you can select which mode to use and the GUI will adapt itself.
(Todo show how to switch mode)
