
.. include:: ../rst_prolog.rst


.. _svlOtherFileWidget:

Other File widget
------------------

This widget displays the content of the selected med file.
It use the MEDCoupling API to do so.

.. image:: images/solverlabOtherTab.png

How to use
.....................

The user can *mouse-right-click* on the fileMed field in the **TREE VIEW** and select the "Dump ascii content" context menu.

