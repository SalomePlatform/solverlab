
.. include:: ../rst_prolog.rst


.. _iraMainWidget:

Solverlab GUI main widget
---------------------------

This is the main window of the Solverlab GUI. It's composed of three parts:

#. The **TOOLBAR** is at the top and is used to realise quick action
#. The **TREE VIEW** is at the left and is used to import and modifie all data needed by Solverlab.
#. The **CONTENT TAB** is at the center/right and has diverse utility


.. image:: images/solverlabMainWidget1.png
   :scale: 75 %
   :align: center


.. _iraMainWidgetToolbar:

Toolbar
.....................


.. image:: images/solverlabMainWidgetToolbar1n.png
   :align: center

This toolbar contains icons related to actions, from left to right:

#. New Solverlab data. Create solverlab case from scratch
#. Load Solverlab data. Load case from previously saved case in a file Xml.
#. Save Solverlab data. Save current solverlab case in a file Xml.
#. Launch Solverlab calculus. Launch Solverlab code on current solverlab case.
#. Refresh SolverlabObjects tree view.
#. Clear Solverlab data model, remove Solverlab data tree (in SolverlabObject widget).
#. Solverlab GUI help. Display this current documentation in a browser (html mode).
#. Solverlab code help. Display Solverlab code manual in a browser (pdf mode).
#. Solverlab Example. Show directory with example of implemented model.
