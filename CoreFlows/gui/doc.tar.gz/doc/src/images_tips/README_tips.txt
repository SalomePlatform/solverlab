## HOWTO 

oodraw tips_text_arrows_draw.odg
copy paste modify items

gimp *.xcf

copy paste from oodraw texts and arrows into gimp as new calque(s)

gimp export as tip_nn_xxxxxxx.png
